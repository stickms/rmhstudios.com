-- The optional packs this mp pack expects (build-game-pack.py).
return {release={file="release-d8bacd17f552.zip",sha256="d8bacd17f55271124faa33c0a44dd837a75e2a7689a14394361240f81a159f9a"}}
